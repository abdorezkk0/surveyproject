import Survey from '../models/Survey.js';

// @desc    Fetch all surveys
// @route   GET /api/surveys
// @access  Public
const getSurveys = async (req, res) => {
  const surveys = await Survey.find({});
  res.json(surveys);
};

export { getSurveys };

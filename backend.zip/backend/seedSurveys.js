import mongoose from 'mongoose';
import dotenv from 'dotenv';
import connectDB from './config/db.js';
import Survey from './models/Survey.js';

dotenv.config();
connectDB();

const importData = async () => {
  try {
    await Survey.deleteMany();

    const sampleSurveys = [
      { title: 'Customer Feedback', description: 'Survey about customer satisfaction.' },
      { title: 'Employee Engagement', description: 'Survey about employee workplace engagement.' },
      { title: 'Market Research', description: 'Survey about product-market fit.' },
    ];

    await Survey.insertMany(sampleSurveys);
    console.log('Data Imported!');
    process.exit();
  } catch (error) {
    console.error(`${error}`);
    process.exit(1);
  }
};

importData();

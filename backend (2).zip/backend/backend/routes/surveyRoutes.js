import express from 'express';
import { getSurveys } from '../controllers/surveyController.js';

const router = express.Router();

router.route('/').get(getSurveys);

export default router;
